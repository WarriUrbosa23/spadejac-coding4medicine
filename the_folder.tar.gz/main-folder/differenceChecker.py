f = open("/home/spadejac/main-folder/coronaviruses.aln")
lines = f.readlines()
print(lines)
