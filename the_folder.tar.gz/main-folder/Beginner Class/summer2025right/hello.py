import time
print("to anyone who sees this:")
x = 0 
while x < 5:
    print(".", end="")
    time.sleep(2)
