import gffutils
from Bio import SeqIO
from Bio.Seq import Seq


def main():
    ALDH2 = open("/share/Human/aldh2.gff")
    